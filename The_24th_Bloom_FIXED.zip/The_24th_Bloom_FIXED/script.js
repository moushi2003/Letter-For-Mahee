/* =========================================================
   MAHEE — CINEMATIC BIRTHDAY
   INTEGRATED / FIXED MASTER SCRIPT
========================================================= */

document.addEventListener("DOMContentLoaded", () => {
    const pages = [
        document.getElementById("birthdayPage"),
        document.getElementById("birthdayLetterPage"),
        document.getElementById("memoriesPage"),
        document.getElementById("friendshipLetterPage"),
        document.getElementById("bouquetPage"),
        document.getElementById("grandFinalePage")
    ].filter(Boolean);

    let currentPage = 0;
    let curtainOpened = false;
    let finaleStarted = false;

    /* =====================================================
       PAGE NAVIGATION
    ===================================================== */
    function showPage(index) {
        if (!pages.length) return;
        index = Math.max(0, Math.min(index, pages.length - 1));

        pages.forEach((page, i) => {
            page.classList.toggle("active-page", i === index);
        });

        currentPage = index;

        if (pages[index].id === "grandFinalePage") {
            startFinale();
        }
    }

    function nextPage() { showPage(currentPage + 1); }
    function previousPage() { showPage(currentPage - 1); }

    /* Exact button IDs from the uploaded HTML */
    const buttonMap = {
        birthdayLetterNextBtn: 1,
        memoriesNextBtn: 3,
        friendshipLetterNextBtn: 4,
        bouquetNextBtn: 5
    };

    Object.entries(buttonMap).forEach(([id, target]) => {
        const btn = document.getElementById(id);
        if (btn) btn.addEventListener("click", () => showPage(target));
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "ArrowRight") nextPage();
        if (event.key === "ArrowLeft") previousPage();
    });

    window.showCinematicPage = showPage;
    window.nextCinematicPage = nextPage;
    window.previousCinematicPage = previousPage;

    /* =====================================================
       BIRTHDAY CURTAIN
       CSS expects .birthday-page.curtain-open
    ===================================================== */
    const birthdayPage = document.getElementById("birthdayPage");
    const birthdayCurtain = document.getElementById("birthdayCurtain");

    function openBirthdayCurtain() {
        if (!birthdayPage || curtainOpened) return;
        curtainOpened = true;
        setTimeout(() => birthdayPage.classList.add("curtain-open"), 350);
        setTimeout(() => {
            if (birthdayCurtain) birthdayCurtain.style.pointerEvents = "none";
        }, 2600);
    }

    window.openBirthdayCurtain = openBirthdayCurtain;
    setTimeout(openBirthdayCurtain, 900);

    /* =====================================================
       BIRTHDAY CELEBRATION
    ===================================================== */
    const celebrateBtn = document.getElementById("celebrateBtn");
    const celebrationBalloons = document.getElementById("celebrationBalloons");
    const celebrationConfetti = document.getElementById("celebrationConfetti");
    const celebratedMessage = document.getElementById("celebratedMessage");

    const balloonColors = ["#ff6b81", "#ff9fba", "#ffd166", "#8ec5ff", "#b8a0ff", "#ffffff"];
    const confettiColors = ["#ff6b81", "#ffd166", "#8ec5ff", "#b8a0ff", "#ffffff"];

    function createCelebrationBalloon() {
        if (!celebrationBalloons) return;
        const b = document.createElement("div");
        b.className = "cinematic-balloon";
        const size = Math.random() * 20 + 38;
        b.style.setProperty("--balloon-size", `${size}px`);
        b.style.setProperty("--balloon-left", `${Math.random() * 94 + 3}%`);
        b.style.setProperty("--balloon-duration", `${Math.random() * 4 + 7}s`);
        b.style.setProperty("--balloon-delay", `${Math.random() * .7}s`);
        b.style.setProperty("--balloon-color", balloonColors[Math.floor(Math.random() * balloonColors.length)]);
        celebrationBalloons.appendChild(b);
        setTimeout(() => b.remove(), 9500);
    }

    function launchConfetti() {
        if (!celebrationConfetti) return;
        for (let i = 0; i < 75; i++) {
            const piece = document.createElement("span");
            piece.className = "cinematic-confetti";
            piece.style.left = `${Math.random() * 100}%`;
            piece.style.setProperty("--confetti-color", confettiColors[Math.floor(Math.random() * confettiColors.length)]);
            piece.style.setProperty("--confetti-delay", `${Math.random() * .7}s`);
            piece.style.setProperty("--confetti-x", `${(Math.random() - .5) * 260}px`);
            celebrationConfetti.appendChild(piece);
            setTimeout(() => piece.remove(), 4500);
        }
    }

    function celebrate() {
        if (!birthdayPage) return;
        birthdayPage.classList.add("celebration-started");
        for (let i = 0; i < 30; i++) setTimeout(createCelebrationBalloon, i * 70);
        launchConfetti();
        if (celebratedMessage) {
            celebratedMessage.classList.add("show");
            celebratedMessage.setAttribute("aria-hidden", "false");
        }
        fireworkShow(8, 360);
    }

    if (celebrateBtn) celebrateBtn.addEventListener("click", celebrate);

    /* =====================================================
       MEMORIES — EXACT HTML CLASSES
    ===================================================== */
    const memoriesPage = document.getElementById("memoriesPage");
    const slides = Array.from(document.querySelectorAll(".memory-slide"));
    const dots = Array.from(document.querySelectorAll(".memory-dot"));
    const prevMemory = document.querySelector(".memory-nav-prev");
    const nextMemory = document.querySelector(".memory-nav-next");
    let currentSlide = 0;
    let autoSlideTimer = null;

    function showSlide(index) {
        if (!slides.length) return;
        index = (index + slides.length) % slides.length;
        currentSlide = index;
        slides.forEach((slide, i) => slide.classList.toggle("active-slide", i === index));
        dots.forEach((dot, i) => dot.classList.toggle("active", i === index));
    }

    function restartAutoSlide() {
        clearInterval(autoSlideTimer);
        if (slides.length > 1) {
            autoSlideTimer = setInterval(() => showSlide(currentSlide + 1), 4500);
        }
    }

    if (prevMemory) prevMemory.addEventListener("click", () => { showSlide(currentSlide - 1); restartAutoSlide(); });
    if (nextMemory) nextMemory.addEventListener("click", () => { showSlide(currentSlide + 1); restartAutoSlide(); });
    dots.forEach((dot, i) => dot.addEventListener("click", () => { showSlide(i); restartAutoSlide(); }));

    if (memoriesPage) {
        let startX = 0;
        memoriesPage.addEventListener("touchstart", e => { startX = e.changedTouches[0].clientX; }, { passive: true });
        memoriesPage.addEventListener("touchend", e => {
            const dx = e.changedTouches[0].clientX - startX;
            if (Math.abs(dx) < 45) return;
            showSlide(currentSlide + (dx < 0 ? 1 : -1));
            restartAutoSlide();
        }, { passive: true });
        memoriesPage.addEventListener("mouseenter", () => clearInterval(autoSlideTimer));
        memoriesPage.addEventListener("mouseleave", restartAutoSlide);
    }
    showSlide(0);
    restartAutoSlide();
    window.showMemorySlide = showSlide;

    /* =====================================================
       REALISTIC FIREWORKS
    ===================================================== */
    const canvas = document.getElementById("fireworksCanvas");
    let ctx = null;
    let width = 0;
    let height = 0;
    let rockets = [];
    let particles = [];
    let animationFrame = null;
    let fireworksRunning = false;

    const fireworkColors = ["#ffd6e7", "#ffffff", "#ffe29a", "#b9d7ff", "#d8c4ff", "#ff9fba"];
    const randomColor = () => fireworkColors[Math.floor(Math.random() * fireworkColors.length)];

    if (canvas) {
        ctx = canvas.getContext("2d");
        function resizeCanvas() {
            const ratio = Math.min(window.devicePixelRatio || 1, 2);
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = width * ratio;
            canvas.height = height * ratio;
            canvas.style.width = `${width}px`;
            canvas.style.height = `${height}px`;
            ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
        }
        resizeCanvas();
        window.addEventListener("resize", resizeCanvas);
    }

    function explode(x, y, color) {
        const count = window.innerWidth < 600 ? 55 : 95;
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 5.3 + 1.4;
            particles.push({
                x, y, color,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                life: 1,
                decay: Math.random() * .012 + .009,
                size: Math.random() * 1.5 + .7,
                trail: []
            });
        }
    }

    function launchFirework(targetX, targetY) {
        if (!canvas) return;
        const startX = Math.random() * width;
        const speed = Math.random() * 3 + 7;
        const angle = Math.atan2(targetY - (height + 10), targetX - startX);
        rockets.push({
            x: startX, y: height + 10, targetX, targetY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            color: randomColor(), trail: []
        });
    }

    function launchRandomFirework() {
        launchFirework(width * (.15 + Math.random() * .7), height * (.12 + Math.random() * .42));
    }

    function animateFireworks() {
        if (!ctx) return;
        ctx.fillStyle = "rgba(3,3,8,.18)";
        ctx.fillRect(0, 0, width, height);

        for (let i = rockets.length - 1; i >= 0; i--) {
            const r = rockets[i];
            r.trail.push({x:r.x,y:r.y});
            if (r.trail.length > 7) r.trail.shift();
            r.x += r.vx; r.y += r.vy; r.vy += .035;
            ctx.beginPath();
            r.trail.forEach((p,j) => j ? ctx.lineTo(p.x,p.y) : ctx.moveTo(p.x,p.y));
            ctx.strokeStyle = r.color; ctx.globalAlpha = .65; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.globalAlpha = 1;
            ctx.beginPath(); ctx.arc(r.x,r.y,2,0,Math.PI*2); ctx.fillStyle="#fff"; ctx.shadowBlur=12; ctx.shadowColor=r.color; ctx.fill(); ctx.shadowBlur=0;
            if (Math.hypot(r.targetX-r.x,r.targetY-r.y) < 18 || r.vy > -1) {
                explode(r.x,r.y,r.color); rockets.splice(i,1);
            }
        }

        for (let i = particles.length - 1; i >= 0; i--) {
            const p = particles[i];
            p.trail.push({x:p.x,y:p.y});
            if (p.trail.length > 5) p.trail.shift();
            p.vx *= .985; p.vy *= .985; p.vy += .045; p.x += p.vx; p.y += p.vy; p.life -= p.decay;
            ctx.globalAlpha = Math.max(p.life,0);
            ctx.beginPath(); p.trail.forEach((t,j)=>j?ctx.lineTo(t.x,t.y):ctx.moveTo(t.x,t.y)); ctx.strokeStyle=p.color; ctx.lineWidth=p.size*.7; ctx.stroke();
            ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fillStyle=p.color; ctx.shadowBlur=10; ctx.shadowColor=p.color; ctx.fill(); ctx.shadowBlur=0;
            if (p.life <= 0) particles.splice(i,1);
        }
        ctx.globalAlpha = 1;
        if (fireworksRunning || rockets.length || particles.length) animationFrame = requestAnimationFrame(animateFireworks);
        else animationFrame = null;
    }

    function startFireworks() {
        fireworksRunning = true;
        if (!animationFrame) animateFireworks();
    }
    function stopFireworks() { fireworksRunning = false; }
    function fireworkShow(count=8, interval=420) {
        if (!canvas) return;
        startFireworks();
        let launched = 0;
        const timer = setInterval(() => {
            launchRandomFirework();
            launched++;
            if (launched >= count) {
                clearInterval(timer);
                setTimeout(stopFireworks, 5000);
            }
        }, interval);
    }

    window.fireworkShow = fireworkShow;
    window.launchFirework = launchFirework;
    window.startFireworks = startFireworks;
    window.stopFireworks = stopFireworks;

    /* =====================================================
       FINALE
    ===================================================== */
    function startFinale() {
        if (finaleStarted) return;
        finaleStarted = true;
        setTimeout(() => fireworkShow(16, 420), 700);
        setTimeout(() => fireworkShow(10, 650), 8500);
    }

    /* Start at Birthday page */
    showPage(0);

    console.log("🎬 Integrated cinematic experience initialized.");
});
